# word-processor - Filimon Adrian


# Detalii generale

- Am reusit sa fac intreaga tema, cu mentiunea ca nu am reusit sa rulez checkerul
- Din lipsa de timp, codul este pus doar intr-un singur fisier
- De asemenea, este destul de mult cod duplicat, problema care s-ar fi realizat destul de usor cu mai multe fisiere/functii
- Solutia pare sa scaleze la rularea manuala, dar nu am reusit sa ma folosesc de functionalitatea checkerului

# Implementare

- Am definit mai multe structuri, pentru a trimite argumentele in functiile de thread si pentru a primi un rezultat tot acolo
- am facut functia `tokenize` de mana deoarece este mai rapida, doar ca uneori imi adauga caractere in plus
- functiile pentru workeri sunt facute conform cerintei. Am lasat atat implementarea secventiala, cat si cea pe threaduri

- functia `read_file` este cea care citeste linie cu linie fisierul in cele 4 thread-uri ale statiei Master. 
    - daca se gaseste pe linie cuvantul pe care il cauta thread-ul respectiv(ex. comedy), se va citi pana la new line
    - de mentioanat aici este faptul ca este nevoie ca fisierul sa se termine cu newline pentru a citi si ultiumul paragraf
    - atunci cand se termina paragraful, acesta este trimis la workerul corespunzator si se continua cautarea
    
- workerii deschid un thread pentru a primi un paragraf de la master, apoi incep sa il proceseze cu celelalte threaduri
- datele sunt pastrate intr-o structura de tip `paragraph_line`, unde se afla numarul liniei in fisier si linia efectiva. 
- paragraful este concatenat, apoi se trimite spre procesare
- fiecare paragraf procesat este pastrat intr-un vector de structuri `paragraph_line`, ordinea paragrafului fiind de fapt numarul de orrdine cel mai mic din intreg paragraful. 
- dupa ce se termina paragrafele, toate datele sunt trimise la master
- aici are loc o sortare, apoi se face scrierea in fisier a datelor